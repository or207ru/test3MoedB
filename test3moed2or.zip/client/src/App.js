import React from 'react'
import ServerList from './components/ServerList'

function App() {

    return (
      <div>
        <ServerList></ServerList>
      </div>
    );
  }

  export default App;
